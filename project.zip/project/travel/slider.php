<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>

<body>

			<div id="section-1" class="section">
			    <div id="top" class="callbacks_container">
			      <ul class="rslides" id="slider4">
			        <li>
			          <img src="images/o-TRAVEL-facebook.jpg" alt="">
					  <div class="caption">
			     	  		<div class="header-info">
							<h2>Welcome To My World</h2>
							<lable></lable>
							<h1>Go Travel & Tourism </h1>
							</div>
			          </div>
			        
			    </div>	         
			    <div class="clearfix"> </div>
				</div>

</body>
</html>