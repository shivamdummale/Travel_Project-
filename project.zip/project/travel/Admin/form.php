<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

</head>

<body>
<form>
<table border="1" width="300px" height="300px">
<tr><td colspan="2" align="center">Add User</td></tr>
<tr><td>User Name</td><td><input type="text" /></td></tr>
<tr><td>Password</td><td><input type="password"/></td></tr>
<tr><td>Confirm Password</td><td><input type="password"/></td></tr>
<tr><td>Type of User</td><td><select><option value="Select">Select</option><option value="Admin">Admin</option><option value="General">General</option></select></td></tr>
<tr><td colspan="2" align="center"><input type="button" value="SAVE" /></td></tr>




</table>
</form>
</body>
</html>